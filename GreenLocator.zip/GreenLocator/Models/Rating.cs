﻿using System.ComponentModel.DataAnnotations;

namespace GreenLocator.Models
{
    public class Rating
    {
        [Key]
        public string Id { get; set; }
    }
}
