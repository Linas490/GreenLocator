﻿using System.ComponentModel.DataAnnotations;

namespace GreenLocator.Models
{
    public class Review
    {
        [Key]
        public string Id { get; set; }



    }
}
