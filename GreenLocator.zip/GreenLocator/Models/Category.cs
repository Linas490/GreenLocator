﻿
using System.Collections;
using System.ComponentModel.DataAnnotations;

namespace GreenLocator.Models
{
    public enum Category
    {
        Skalbykle, Orkaite
    }
}
